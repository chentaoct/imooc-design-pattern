package com.geely.design.pattern.structural.bridge;

/**
 * Created by geely
 */
public interface Account {
    Account openAccount();
    void showAccountType();

}
