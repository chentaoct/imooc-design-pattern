package com.geely.design.principle.openclose;

/**
 * Created by geely
 */
public interface ICourse {
    Integer getId();
    String getName();
    Double getPrice();


}
