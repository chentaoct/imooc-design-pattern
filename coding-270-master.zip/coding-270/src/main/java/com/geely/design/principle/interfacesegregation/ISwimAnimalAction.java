package com.geely.design.principle.interfacesegregation;

/**
 * Created by geely
 */
public interface ISwimAnimalAction {
    void swim();
}
