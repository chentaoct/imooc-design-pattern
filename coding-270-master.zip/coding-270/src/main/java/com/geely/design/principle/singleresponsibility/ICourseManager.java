package com.geely.design.principle.singleresponsibility;

/**
 * Created by geely
 */
public interface ICourseManager {
    void studyCourse();
    void refundCourse();
}
