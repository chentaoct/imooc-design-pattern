package com.geely.design.principle.dependenceinversion;

/**
 * Created by geely
 */
public interface ICourse {
    void studyCourse();
}
