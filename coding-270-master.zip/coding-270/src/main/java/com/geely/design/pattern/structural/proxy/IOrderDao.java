package com.geely.design.pattern.structural.proxy;

/**
 * Created by geely
 */
public interface IOrderDao {
    int insert(Order order);

}
