package com.geely.design.pattern.creational.abstractfactory;

/**
 * Created by geely
 */
public abstract class Article {
    public abstract void produce();
}
