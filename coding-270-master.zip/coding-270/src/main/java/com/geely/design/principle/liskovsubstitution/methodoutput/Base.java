package com.geely.design.principle.liskovsubstitution.methodoutput;

import java.util.Map;

/**
 * Created by geely
 */
public abstract class Base {
    public abstract Map method();

}
