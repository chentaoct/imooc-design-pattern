package com.geely.design.pattern.behavioral.iterator;

/**
 * Created by geely.
 */
public class Course {
    private String name;

    public Course(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
